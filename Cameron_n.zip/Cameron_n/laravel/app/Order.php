<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
    protected $fillable = ['person_name', 'email', 'phone', 'address', 'product_name', 'quantity'];
    public $timestamps = false;
}
