<?php $__env->startSection('content'); ?>
    <div class="page-wrapper bg-dark p-t-100 p-b-50">
        <div class="wrapper wrapper--w900">
            <div class="card card-6">
                <div class="card-heading">
                    <h2 class="title">Edit Order Detail</h2>
                </div>
                <div class="card-body">
                    <form method="post" action="<?php echo e(action('ProductController@updateOrder', $id)); ?>">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="_method" value="PATCH" />
                        <div class="form-row">
                            <div class="name">Person name</div>
                            <div class="value">
                                <input class="input--style-6" type="text" name="person_name" value="<?php echo e($order->person_name); ?>">
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="name">Email address</div>
                            <div class="value">
                                <div class="input-group">
                                    <input class="input--style-6" type="email" name="email" value="<?php echo e($order->email); ?>">
                                </div>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="name">Phone</div>
                            <div class="value">
                                <input class="input--style-6" type="number" name="phone" value="<?php echo e($order->phone); ?>">
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="name">Product name</div>
                            <div class="value">
                                <div class="input-group">
                                    <input class="input--style-6" type="text" name="product_name" value="<?php echo e($order->product_name); ?>">
                                </div>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="name">Quantity</div>
                            <div class="value">
                                <div class="input-group">
                                    <input class="input--style-6" type="number" name="quantity" value="<?php echo e($order->quantity); ?>">
                                </div>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="name">Address</div>
                            <div class="value">
                                <div class="input-group">
                                    <input class="input--style-6" name="address"  value="<?php echo e($order->address); ?>" />
                                </div>
                            </div>
                        </div>
                        <div class="card-footer">
                            <button class="btn btn--radius-2 btn--blue-2" type="submit">Update</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<!-- end document-->
<?php echo $__env->make('master2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>