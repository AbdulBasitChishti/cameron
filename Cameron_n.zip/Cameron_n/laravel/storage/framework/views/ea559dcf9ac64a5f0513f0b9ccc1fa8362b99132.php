<?php $__env->startSection('content'); ?>
    <div class="page-wrapper bg-dark p-t-100 p-b-50">
        <div class="wrapper wrapper--w900">
            <div class="card card-6">
                <div class="card-heading">
                    <h2 class="title">Add New Product</h2>
                </div>
                <div class="card-body">
                    <form method="post" action="<?php echo e(route('product.add')); ?>">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="_method" value="PATCH" />
                        <div class="form-row">
                            <div class="name">Name</div>
                            <div class="value">
                                <input class="input--style-6" type="text" name="product_name" required/>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="name">Price ($)</div>
                            <div class="value">
                                <div class="input-group">
                                    <input class="input--style-6" type="number" step="any" name="price" required/>
                                </div>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="name">Description</div>
                            <div class="value">
                                <div class="input-group">
                                    <input class="input--style-6" type="text" name="description" required/>
                                </div>
                            </div>
                        </div>
                        <div class="card-footer">
                            <button class="btn btn--radius-2 btn--blue-2" type="submit">Update</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<!-- end document-->
<?php echo $__env->make('master2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>