<?php $__env->startSection('content'); ?>
<div style="padding-left: 20px; padding-top: 10px"><a href="<?php echo e(url('/')); ?>">Home</a></div>
<div class="container-xl">
	<?php if(count($errors) > 0): ?>
		<div class="alert alert-danger">
			<ul>
				<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<li><?php echo e($error); ?></li>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
	<?php endif; ?>
	<?php if(\Session::has('success')): ?>
		<div class="alert alert-success">
			<p><?php echo e(\Session::get('success')); ?></p>
		</div>
	<?php endif; ?>
	<div class="table-responsive">
		<div class="table-wrapper">
			<div class="table-title">
				<div class="row">
					<div class="col-sm-6">
						<h2>Manage <b>Orders</b></h2>
					</div>
				</div>
			</div>
			<table class="table table-striped table-hover">
				<thead>
					<tr>
						<th>Person Name</th>
						<th>Email</th>
						<th>Phone</th>
						<th>Address</th>
						<th>Product</th>
						<th>Quantity</th>
						<th>Actions</th>
					</tr>
				</thead>
				<tbody>
					<?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e($row['person_name']); ?></td>
						<td><?php echo e($row['email']); ?></td>
						<td><?php echo e($row['phone']); ?></td>
						<td><?php echo e($row['address']); ?></td>
						<td><?php echo e($row['product_name']); ?></td>
						<td><?php echo e($row['quantity']); ?></td>
						
						<td>
							<a href="<?php echo e(action('ProductController@editOrder', $row['id'])); ?>" class="edit"><i class="material-icons" data-toggle="tooltip" title="Edit">&#xE254;</i></a>
							<a href="<?php echo e(route('order.delete', $row['id'])); ?>" onclick="return confirmP()" class="delete"><i class="material-icons" data-toggle="tooltip" title="Delete">&#xE872;</i></a>
						</td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>
		</div>
	</div>        
</div>

<div class="container-xl">
	<div class="table-responsive">
		<div class="table-wrapper">
			<div class="table-title">
				<div class="row">
					<div class="col-sm-6">
						<h2>Manage <b>Products</b></h2>
					</div>
					<div class="col-sm-6">
						<a href="<?php echo e(action('ProductController@create')); ?>" class="btn btn-success"><i class="material-icons">&#xE147;</i> <span>Add New Product</span></a>
					</div>
				</div>
			</div>
			<table class="table table-striped table-hover">
				<thead>
					<tr>
						<th>Name</th>
						<th>Price</th>
						<th>Descrption</th>
						<th>Actions</th>
					</tr>
				</thead>
				<tbody>
					<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e($row['product_name']); ?></td>
						<td><?php echo e($row['price']); ?> $</td>
						<td><?php echo e($row['description']); ?></td>
						<td>
							<a href="<?php echo e(action('ProductController@edit', $row['id'])); ?>" class="edit"><i class="material-icons" data-toggle="tooltip" title="Edit">&#xE254;</i></a>
							<a href="<?php echo e(route('product.delete', $row['id'])); ?>" onclick="return confirmP()" class="delete"><i class="material-icons" data-toggle="tooltip" title="Delete">&#xE872;</i></a>
						</td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>
		</div>
	</div>        
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>