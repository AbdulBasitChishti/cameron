@extends('master')

@section('content')
<div style="padding-left: 20px; padding-top: 10px"><a href="{{ url('/') }}">Home</a></div>
<div class="container-xl">
	@if(count($errors) > 0)
		<div class="alert alert-danger">
			<ul>
				@foreach($errors->all() as $error)
					<li>{{$error}}</li>
				@endforeach
		</div>
	@endif
	@if(\Session::has('success'))
		<div class="alert alert-success">
			<p>{{\Session::get('success')}}</p>
		</div>
	@endif
	<div class="table-responsive">
		<div class="table-wrapper">
			<div class="table-title">
				<div class="row">
					<div class="col-sm-6">
						<h2>Manage <b>Orders</b></h2>
					</div>
				</div>
			</div>
			<table class="table table-striped table-hover">
				<thead>
					<tr>
						<th>Person Name</th>
						<th>Email</th>
						<th>Phone</th>
						<th>Address</th>
						<th>Product</th>
						<th>Quantity</th>
						<th>Actions</th>
					</tr>
				</thead>
				<tbody>
					@foreach($orders as $row)
					<tr>
						<td>{{$row['person_name']}}</td>
						<td>{{$row['email']}}</td>
						<td>{{$row['phone']}}</td>
						<td>{{$row['address']}}</td>
						<td>{{$row['product_name']}}</td>
						<td>{{$row['quantity']}}</td>
						
						<td>
							<a href="{{ action('ProductController@editOrder', $row['id']) }}" class="edit"><i class="material-icons" data-toggle="tooltip" title="Edit">&#xE254;</i></a>
							<a href="{{ route('order.delete', $row['id']) }}" onclick="return confirmP()" class="delete"><i class="material-icons" data-toggle="tooltip" title="Delete">&#xE872;</i></a>
						</td>
					</tr>
				@endforeach
				</tbody>
			</table>
		</div>
	</div>        
</div>

<div class="container-xl">
	<div class="table-responsive">
		<div class="table-wrapper">
			<div class="table-title">
				<div class="row">
					<div class="col-sm-6">
						<h2>Manage <b>Products</b></h2>
					</div>
					<div class="col-sm-6">
						<a href="{{ action('ProductController@create') }}" class="btn btn-success"><i class="material-icons">&#xE147;</i> <span>Add New Product</span></a>
					</div>
				</div>
			</div>
			<table class="table table-striped table-hover">
				<thead>
					<tr>
						<th>Name</th>
						<th>Price</th>
						<th>Descrption</th>
						<th>Actions</th>
					</tr>
				</thead>
				<tbody>
					@foreach($products as $row)
					<tr>
						<td>{{$row['product_name']}}</td>
						<td>{{$row['price']}} $</td>
						<td>{{$row['description']}}</td>
						<td>
							<a href="{{ action('ProductController@edit', $row['id']) }}" class="edit"><i class="material-icons" data-toggle="tooltip" title="Edit">&#xE254;</i></a>
							<a href="{{ route('product.delete', $row['id']) }}" onclick="return confirmP()" class="delete"><i class="material-icons" data-toggle="tooltip" title="Delete">&#xE872;</i></a>
						</td>
					</tr>
				@endforeach
				</tbody>
			</table>
		</div>
	</div>        
</div>

@endsection