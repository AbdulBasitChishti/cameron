<!DOCTYPE HTML>
<html>
	<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Cameron &mdash; For your dreams</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">

  	<!-- Facebook and Twitter integration -->
	<meta property="og:title" content=""/>
	<meta property="og:image" content=""/>
	<meta property="og:url" content=""/>
	<meta property="og:site_name" content=""/>
	<meta property="og:description" content=""/>
	<meta name="twitter:title" content="" />
	<meta name="twitter:image" content="" />
	<meta name="twitter:url" content="" />
	<meta name="twitter:card" content="" />

	<!-- <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet"> -->
	<!-- <link href="https://fonts.googleapis.com/css?family=Playfair+Display:400,400i" rel="stylesheet"> -->
	
	<!-- Animate.css -->
	<link rel="stylesheet" href="css/animate.css">
	<!-- Icomoon Icon Fonts-->
	<link rel="stylesheet" href="css/icomoon.css">
	<!-- Bootstrap  -->
	<link rel="stylesheet" href="css/bootstrap.css">

	<!-- Flexslider  -->
	<link rel="stylesheet" href="css/flexslider.css">

	<!-- Owl Carousel  -->
	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<link rel="stylesheet" href="css/owl.theme.default.min.css">

	<!-- Theme style  -->
	<link rel="stylesheet" href="css/style.css">

	<!-- Font Awesome -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">

	<!-- Modernizr JS -->
	<script src="js/modernizr-2.6.2.min.js"></script>
	<!-- FOR IE9 below -->
	<!--[if lt IE 9]>
	<script src="js/respond.min.js"></script>
	<![endif]-->

	</head>
	<body>
		
	<div class="fh5co-loader"></div>
	
	<div id="page">
	<nav class="fh5co-nav" role="navigation">
		<div class="container">
			<div class="row">
				<div class="col-md-3 col-xs-2">
					<div id="fh5co-logo"><a href="{{ url('/login') }}">Beckieddia</a></div>
				</div>
				<div class="col-md-6 col-xs-6 text-center menu-1">
					<ul>
						<li><a href="{{ url('/') }}">Cameron</a></li>
						<li><a href="{{ url('/brands') }}">Women</a></li>
						<li><a href="{{ url('/brands') }}">Men</a></li>
						<li><a href="{{ url('/brands') }}">Child</a></li>
						<li><a href="{{ url('/amazon') }}">Shop on demand</a></li>
						<li><a href="{{ url('/contact') }}">Contact</a></li>
					</ul>
				</div>
				<div class="col-md-3 col-xs-4 text-right hidden-xs menu-2">
					<ul>
						<!-- <li class="search">
							<div class="input-group">
						      <input type="text" placeholder="Search..">
						      <span class="input-group-btn">
						        <button class="btn btn-primary" type="button"><i class="icon-search"></i></button>
						      </span>
						    </div>
						</li> -->
						<li class="user-account has-dropdown">
							<a href="#" class="account hide"><i class="fas fa-user"></i></a>
							<a class="account" href="{{ url('/login') }}">Login</a>
							<a class="account" href="{{ url('/admin') }}">Admin</a>
							<span class="dropdown hide" id="user-name">Hamid</span>
						</li>
						<li class="shopping-cart"><a href="{[ url('/cart') }}" class="cart"><span><small>0</small><i class="icon-shopping-cart"></i></span></a></li>
					</ul>
				</div>
			</div>
		</div>
	</nav>
	
	<aside id="fh5co-hero" class="js-fullheight">
		<div class="flexslider js-fullheight">
			<ul class="slides">
		   	<li style="background: url(images/dress-1.jpg) no-repeat; background-size: cover;">
		   		<div class="overlay-gradient"></div>
		   		<div class="container">
		   			<div class="col-md-6 col-md-offset-3 col-md-pull-3 js-fullheight slider-text">
		   				<div class="slider-text-inner">
		   					<div class="desc">
		   						<span class="price">$800</span>
		   						<h2>Alato Cabinet</h2>
		   						<p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts. Separated they live in Bookmarksgrove.</p>
			   					<p><a href="{{ url('/single') }}" class="btn btn-primary btn-outline btn-lg">Purchase Now</a></p>
		   					</div>
		   				</div>
		   			</div>
		   		</div>
		   	</li>
		   	<li style="background: url(images/dress-2.jpg) no-repeat; background-size: cover;">
		   		<div class="container">
		   			<div class="col-md-6 col-md-offset-3 col-md-pull-3 js-fullheight slider-text">
		   				<div class="slider-text-inner">
		   					<div class="desc">
		   						<span class="price">$530</span>
		   						<h2>The Haluz Rocking Chair</h2>
		   						<p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts. Separated they live in Bookmarksgrove.</p>
			   					<p><a href="{{ url('/single') }}" class="btn btn-primary btn-outline btn-lg">Purchase Now</a></p>
		   					</div>
		   				</div>
		   			</div>
		   		</div>
		   	</li>
		   	<li style="background: url(images/dress-3.jpg) no-repeat; background-size: cover;">
		   		<div class="container">
		   			<div class="col-md-6 col-md-offset-3 col-md-pull-3 js-fullheight slider-text">
		   				<div class="slider-text-inner">
		   					<div class="desc">
		   						<span class="price">$750</span>
		   						<h2>Alato Cabinet</h2>
		   						<p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts. Separated they live in Bookmarksgrove.</p>
			   					<p><a href="{{ url('/single') }}" class="btn btn-primary btn-outline btn-lg">Purchase Now</a></p>
		   					</div>
		   				</div>
		   			</div>
		   		</div>
		   	</li>
		   	<li style="background: url(images/dress-4.jpg) no-repeat; background-size: cover;">
		   		<div class="container">
		   			<div class="col-md-6 col-md-offset-3 col-md-pull-3 js-fullheight slider-text">
		   				<div class="slider-text-inner">
		   					<div class="desc">
		   						<span class="price">$540</span>
		   						<h2>The WW Chair</h2>
		   						<p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts. Separated they live in Bookmarksgrove.</p>
			   					<p><a href="{{ url('/single') }}" class="btn btn-primary btn-outline btn-lg">Purchase Now</a></p>
		   					</div>
		   				</div>
		   			</div>
		   		</div>
		   	</li>
		  	</ul>
	  	</div>
	</aside>

	<div id="fh5co-services" class="fh5co-bg-section">
		<div class="container">
			<div class="row">
				<div class="col-md-4 col-sm-4 text-center">
					<div class="feature-center animate-box" data-animate-effect="fadeIn">
						<span class="icon">
							<i class="icon-credit-card"></i>
						</span>
						<h3>Secure Checkout</h3>
						<p>Donec gravida tincidunt euismod. Mauris lacus mi, vulputate eget sem
							vitae, imperdiet consectetur urna. In ante sapien, mattis eu nisi ut,
							malesuada fringilla massa.
						</p>
						<!-- <p><a href="#" class="btn btn-primary btn-outline">Learn More</a></p> -->
					</div>
				</div>
				<div class="col-md-4 col-sm-4 text-center">
					<div class="feature-center animate-box" data-animate-effect="fadeIn">
						<span class="icon">
							<i class="icon-wallet"></i>
						</span>
						<h3>Save Money</h3>
						<p>Donec gravida tincidunt euismod. Mauris lacus mi, vulputate eget sem
							vitae, imperdiet consectetur urna. In ante sapien, mattis eu nisi ut,
							malesuada fringilla massa.</p>
						<!-- <p><a href="#" class="btn btn-primary btn-outline">Learn More</a></p> -->
					</div>
				</div>
				<div class="col-md-4 col-sm-4 text-center">
					<div class="feature-center animate-box" data-animate-effect="fadeIn">
						<span class="icon">
							<i class="icon-paper-plane"></i>
						</span>
						<h3>Fast Delivery</h3>
						<p>Donec gravida tincidunt euismod. Mauris lacus mi, vulputate eget sem
							vitae, imperdiet consectetur urna. In ante sapien, mattis eu nisi ut,
							malesuada fringilla massa.
						</p>
						<!-- <p><a href="#" class="btn btn-primary btn-outline">Learn More</a></p> -->
					</div>
				</div>
			</div>
		</div>
	</div>


<!-- ------------------------------- LATEST ARRIVALS ----------------------------- -->	
	<div id="fh5co-product">
		<div class="container">
			<div class="row animate-box">
				<div class="col-md-8 col-md-offset-2 text-center fh5co-heading">
					<span>Cool Stuff</span>
					<h2>Latest Arrivals.</h2>
				</div>
			</div>
			<div class="container">
				<div class="row">
					<div class="col-md-3 col-sm-6 animate-box">
						<div class="product">
							<div class="text-center product-grid" style="background-image:url(images/kc-1.jpg);">
								<div class="inner">
									<p>
										<a href="{{ url('/single') }}" class="icon"><i class="icon-shopping-cart"></i></a>
										<a href="{{ url('/single') }}" class="icon"><i class="icon-eye"></i></a>
									</p>
								</div>
							</div>
							<div class="desc">
								<h3><a href="{{ url('/single') }}">Rocking Chair</a></h3>
								<span class="price">$350</span>
							</div>
						</div>
					</div>
					<div class="col-md-3 col-sm-6 animate-box">
						<div class="product">
							<div class="text-center product-grid" style="background-image:url(images/kc-2.jpg);">
								<div class="inner">
									<p>
										<a href="{{ url('/single') }}" class="icon"><i class="icon-shopping-cart"></i></a>
										<a href="{{ url('/single') }}" class="icon"><i class="icon-eye"></i></a>
									</p>
								</div>
							</div>
							<div class="desc">
								<h3><a href="{{ url('/single') }}">Pavilion Speaker</a></h3>
								<span class="price">$600</span>
							</div>
						</div>
					</div>
					<div class="col-md-3 col-sm-6 animate-box">
						<div class="product">
							<div class="text-center product-grid" style="background-image:url(images/kc-3.jpg);">
								<div class="inner">
									<p>
										<a href="{{ url('/single') }}" class="icon"><i class="icon-shopping-cart"></i></a>
										<a href="{{ url('/single') }}" class="icon"><i class="icon-eye"></i></a>
									</p>
								</div>
							</div>
							<div class="desc">
								<h3><a href="{{ url('/single') }}">Alato Cabinet</a></h3>
								<span class="price">$800</span>
							</div>
						</div>
					</div>
					<div class="col-md-3 col-sm-6 animate-box">
						<div class="product">
							<div class="text-center product-grid" style="background-image:url(images/kc-4.jpg);">
								<div class="inner">
									<p>
										<a href="{{ url('/single') }}" class="icon"><i class="icon-shopping-cart"></i></a>
										<a href="{{ url('/single') }}" class="icon"><i class="icon-eye"></i></a>
									</p>
								</div>
							</div>
							<div class="desc">
								<h3><a href="{{ url('/single') }}">Ligomancer</a></h3>
								<span class="price">$780</span>
							</div>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-md-3 col-sm-6 animate-box">
						<div class="product">
							<div class="text-center product-grid" style="background-image:url(images/kc-5.jpg);">
								<div class="inner">
									<p>
										<a href="{{ url('/single') }}" class="icon"><i class="icon-shopping-cart"></i></a>
										<a href="{{ url('/single') }}" class="icon"><i class="icon-eye"></i></a>
									</p>
								</div>
							</div>
							<div class="desc">
								<h3><a href="{{ url('/single') }}">Alato Cabinet</a></h3>
								<span class="price">$800</span>
							</div>
						</div>
					</div>
					<div class="col-md-3 col-sm-6 animate-box">
						<div class="product">
							<div class="text-center product-grid" style="background-image:url(images/kc-6.jpg);">
								<div class="inner">
									<p>
										<a href="{{ url('/single') }}" class="icon"><i class="icon-shopping-cart"></i></a>
										<a href="{{ url('/single') }}" class="icon"><i class="icon-eye"></i></a>
									</p>
								</div>
							</div>
							<div class="desc">
								<h3><a href="{{ url('/single') }}">Earing Wireless</a></h3>
								<span class="price">$100</span>
							</div>
						</div>
					</div>
					<div class="col-md-3 col-sm-6 animate-box">
						<div class="product">
							<div class="text-center product-grid" style="background-image:url(images/kc-7.jpg);">
								<div class="inner">
									<p>
										<a href="{{ url('/single') }}" class="icon"><i class="icon-shopping-cart"></i></a>
										<a href="{{ url('/single') }}" class="icon"><i class="icon-eye"></i></a>
									</p>
								</div>
							</div>
							<div class="desc">
								<h3><a href="{{ url('/single') }}">Sculptural Coffee Table</a></h3>
								<span class="price">$960</span>
							</div>
						</div>
					</div>
					<div class="col-md-3 col-sm-6 animate-box">
						<div class="product">
							<div class="text-center product-grid" style="background-image:url(images/kc-8.jpg);">
								<div class="inner">
									<p>
										<a href="{{ url('/single') }}" class="icon"><i class="icon-shopping-cart"></i></a>
										<a href="{{ url('/single') }}" class="icon"><i class="icon-eye"></i></a>
									</p>
								</div>
							</div>
							<div class="desc">
								<h3><a href="{{ url('/single') }}">Alato Cabinet</a></h3>
								<span class="price">$800</span>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
<!-- ---------------x--------------- LATEST ARRIVALS ---------------x------------- -->	

<!-- --------------------------------- OUR PRODUCTS ------------------------------ -->
	<div id="fh5co-product">
		<div class="container">
			<div class="row animate-box">
				<div class="col-md-8 col-md-offset-2 text-center fh5co-heading">
					<h2>OUR PRODUCTS.</h2>
				</div>
			</div>
			<div class="container">
				<div class="row">
					<div class="col-md-3 col-sm-6 animate-box">
						<div class="product">
							<div class="text-center product-grid" style="background-image:url(images/kc-1.jpg);">
								<div class="inner">
									<p>
										<a href="{{ url('/single') }}" class="icon"><i class="icon-shopping-cart"></i></a>
										<a href="{{ url('/single') }}" class="icon"><i class="icon-eye"></i></a>
									</p>
								</div>
							</div>
							<div class="desc">
								<h3><a href="{{ url('/single') }}">Rocking Chair</a></h3>
								<span class="price">$350</span>
							</div>
						</div>
					</div>
					<div class="col-md-3 col-sm-6 animate-box">
						<div class="product">
							<div class="text-center product-grid" style="background-image:url(images/kc-2.jpg);">
								<div class="inner">
									<p>
										<a href="{{ url('/single') }}" class="icon"><i class="icon-shopping-cart"></i></a>
										<a href="{{ url('/single') }}" class="icon"><i class="icon-eye"></i></a>
									</p>
								</div>
							</div>
							<div class="desc">
								<h3><a href="{{ url('/single') }}">Pavilion Speaker</a></h3>
								<span class="price">$600</span>
							</div>
						</div>
					</div>
					<div class="col-md-3 col-sm-6 animate-box">
						<div class="product">
							<div class="text-center product-grid" style="background-image:url(images/kc-3.jpg);">
								<div class="inner">
									<p>
										<a href="{{ url('/single') }}" class="icon"><i class="icon-shopping-cart"></i></a>
										<a href="{{ url('/single') }}" class="icon"><i class="icon-eye"></i></a>
									</p>
								</div>
							</div>
							<div class="desc">
								<h3><a href="{{ url('/single') }}">Alato Cabinet</a></h3>
								<span class="price">$800</span>
							</div>
						</div>
					</div>
					<div class="col-md-3 col-sm-6 animate-box">
						<div class="product">
							<div class="text-center product-grid" style="background-image:url(images/kc-4.jpg);">
								<div class="inner">
									<p>
										<a href="{{ url('/single') }}" class="icon"><i class="icon-shopping-cart"></i></a>
										<a href="{{ url('/single') }}" class="icon"><i class="icon-eye"></i></a>
									</p>
								</div>
							</div>
							<div class="desc">
								<h3><a href="{{ url('/single') }}">Ligomancer</a></h3>
								<span class="price">$780</span>
							</div>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-md-3 col-sm-6 animate-box">
						<div class="product">
							<div class="text-center product-grid" style="background-image:url(images/kc-5.jpg);">
								<div class="inner">
									<p>
										<a href="{{ url('/single') }}" class="icon"><i class="icon-shopping-cart"></i></a>
										<a href="{{ url('/single') }}" class="icon"><i class="icon-eye"></i></a>
									</p>
								</div>
							</div>
							<div class="desc">
								<h3><a href="{{ url('/single') }}">Alato Cabinet</a></h3>
								<span class="price">$800</span>
							</div>
						</div>
					</div>
					<div class="col-md-3 col-sm-6 animate-box">
						<div class="product">
							<div class="text-center product-grid" style="background-image:url(images/kc-6.jpg);">
								<div class="inner">
									<p>
										<a href="{{ url('/single') }}" class="icon"><i class="icon-shopping-cart"></i></a>
										<a href="{{ url('/single') }}" class="icon"><i class="icon-eye"></i></a>
									</p>
								</div>
							</div>
							<div class="desc">
								<h3><a href="{{ url('/single') }}">Earing Wireless</a></h3>
								<span class="price">$100</span>
							</div>
						</div>
					</div>
					<div class="col-md-3 col-sm-6 animate-box">
						<div class="product">
							<div class="text-center product-grid" style="background-image:url(images/kc-7.jpg);">
								<div class="inner">
									<p>
										<a href="{{ url('/single') }}" class="icon"><i class="icon-shopping-cart"></i></a>
										<a href="{{ url('/single') }}" class="icon"><i class="icon-eye"></i></a>
									</p>
								</div>
							</div>
							<div class="desc">
								<h3><a href="{{ url('/single') }}">Sculptural Coffee Table</a></h3>
								<span class="price">$960</span>
							</div>
						</div>
					</div>
					<div class="col-md-3 col-sm-6 animate-box">
						<div class="product">
							<div class="text-center product-grid" style="background-image:url(images/kc-8.jpg);">
								<div class="inner">
									<p>
										<a href="{{ url('/single') }}" class="icon"><i class="icon-shopping-cart"></i></a>
										<a href="{{ url('/single') }}" class="icon"><i class="icon-eye"></i></a>
									</p>
								</div>
							</div>
							<div class="desc">
								<h3><a href="{{ url('/single') }}">Alato Cabinet</a></h3>
								<span class="price">$800</span>
							</div>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-md-3 col-sm-6 animate-box">
						<div class="product">
							<div class="text-center product-grid" style="background-image:url(images/kc-1.jpg);">
								<div class="inner">
									<p>
										<a href="{{ url('/single') }}" class="icon"><i class="icon-shopping-cart"></i></a>
										<a href="{{ url('/single') }}" class="icon"><i class="icon-eye"></i></a>
									</p>
								</div>
							</div>
							<div class="desc">
								<h3><a href="{{ url('/single') }}">Alato Cabinet</a></h3>
								<span class="price">$800</span>
							</div>
						</div>
					</div>
					<div class="col-md-3 col-sm-6 animate-box">
						<div class="product">
							<div class="text-center product-grid" style="background-image:url(images/kc-2.jpg);">
								<div class="inner">
									<p>
										<a href="{{ url('/single') }}" class="icon"><i class="icon-shopping-cart"></i></a>
										<a href="{{ url('/single') }}" class="icon"><i class="icon-eye"></i></a>
									</p>
								</div>
							</div>
							<div class="desc">
								<h3><a href="{{ url('/single') }}">Earing Wireless</a></h3>
								<span class="price">$100</span>
							</div>
						</div>
					</div>
					<div class="col-md-3 col-sm-6 animate-box">
						<div class="product">
							<div class="text-center product-grid" style="background-image:url(images/kc-3.jpg);">
								<div class="inner">
									<p>
										<a href="{{ url('/single') }}" class="icon"><i class="icon-shopping-cart"></i></a>
										<a href="{{ url('/single') }}" class="icon"><i class="icon-eye"></i></a>
									</p>
								</div>
							</div>
							<div class="desc">
								<h3><a href="{{ url('/single') }}">Alato Cabinet</a></h3>
								<span class="price">$800</span>
							</div>
						</div>
					</div>
					<div class="col-md-3 col-sm-6 animate-box">
						<div class="product">
							<div class="text-center product-grid" style="background-image:url(images/kc-4.jpg);">
								<div class="inner">
									<p>
										<a href="{{ url('/single') }}" class="icon"><i class="icon-shopping-cart"></i></a>
										<a href="{{ url('/single') }}" class="icon"><i class="icon-eye"></i></a>
									</p>
								</div>
							</div>
							<div class="desc">
								<h3><a href="{{ url('/single') }}">Sculptural Coffee Table</a></h3>
								<span class="price">$960</span>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
<!-- ----------------x---------------- OUR PRODUCTS ---------------x-------------- -->

<!--	
	<div id="fh5co-testimonial" class="fh5co-bg-section">
		<div class="container">
			<div class="row animate-box">
				<div class="col-md-8 col-md-offset-2 text-center fh5co-heading">
					<span>Testimony</span>
					<h2>Happy Clients</h2>
				</div>
			</div>
			<div class="row">
				<div class="col-md-10 col-md-offset-1">
					<div class="row animate-box">
						<div class="owl-carousel owl-carousel-fullwidth">
							<div class="item">
								<div class="testimony-slide active text-center">
									<figure>
										<img src="images/person1.jpg" alt="user">
									</figure>
									<span>Jean Doe, via <a href="#" class="twitter">Twitter</a></span>
									<blockquote>
										<p>&ldquo;Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts. Separated they live in Bookmarksgrove right at the coast of the Semantics, a large language ocean.&rdquo;</p>
									</blockquote>
								</div>
							</div>
							<div class="item">
								<div class="testimony-slide active text-center">
									<figure>
										<img src="images/person2.jpg" alt="user">
									</figure>
									<span>John Doe, via <a href="#" class="twitter">Twitter</a></span>
									<blockquote>
										<p>&ldquo;Separated they live in Bookmarksgrove right at the coast of the Semantics, a large language ocean.&rdquo;</p>
									</blockquote>
								</div>
							</div>
							<div class="item">
								<div class="testimony-slide active text-center">
									<figure>
										<img src="images/person3.jpg" alt="user">
									</figure>
									<span>John Doe, via <a href="#" class="twitter">Twitter</a></span>
									<blockquote>
										<p>&ldquo;Far from the countries Vokalia and Consonantia, there live the blind texts. Separated they live in Bookmarksgrove right at the coast of the Semantics, a large language ocean.&rdquo;</p>
									</blockquote>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	
-->
<!-- 
	<div id="fh5co-counter" class="fh5co-bg fh5co-counter" style="background-image:url(images/img_bg_5.jpg);">
		<div class="container">
			<div class="row">
				<div class="display-t">
					<div class="display-tc">
						<div class="col-md-3 col-xs-6 col-xxs-12 animate-box">
							<div class="feature-center">
								<span class="icon">
									<i class="icon-eye"></i>
								</span>

								<span class="counter js-counter" data-from="0" data-to="22070" data-speed="5000" data-refresh-interval="50">1</span>
								<span class="counter-label">Creativity Fuel</span>

							</div>
						</div>
						<div class="col-md-3 col-xs-6 col-xxs-12 animate-box">
							<div class="feature-center">
								<span class="icon">
									<i class="icon-shopping-cart"></i>
								</span>

								<span class="counter js-counter" data-from="0" data-to="450" data-speed="5000" data-refresh-interval="50">1</span>
								<span class="counter-label">Happy Clients</span>
							</div>
						</div>
						<div class="col-md-3 col-xs-6 col-xxs-12 animate-box">
							<div class="feature-center">
								<span class="icon">
									<i class="icon-shop"></i>
								</span>
								<span class="counter js-counter" data-from="0" data-to="700" data-speed="5000" data-refresh-interval="50">1</span>
								<span class="counter-label">All Products</span>
							</div>
						</div>
						<div class="col-md-3 col-xs-6 col-xxs-12 animate-box">
							<div class="feature-center">
								<span class="icon">
									<i class="icon-clock"></i>
								</span>

								<span class="counter js-counter" data-from="0" data-to="5605" data-speed="5000" data-refresh-interval="50">1</span>
								<span class="counter-label">Hours Spent</span>

							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
-->

	<!-- <div id="fh5co-started">
		<div class="container">
			<div class="row animate-box">
				<div class="col-md-8 col-md-offset-2 text-center fh5co-heading">
					<h2>Newsletter</h2>
					<p>Just stay tune for our latest Product. Now you can subscribe</p>
				</div>
			</div>
			<div class="row animate-box">
				<div class="col-md-8 col-md-offset-2">
					<form class="form-inline">
						<div class="col-md-6 col-sm-6">
							<div class="form-group">
								<label for="email" class="sr-only">Email</label>
								<input type="email" class="form-control" id="email" placeholder="Email">
							</div>
						</div>
						<div class="col-md-6 col-sm-6">
							<button type="submit" class="btn btn-default btn-block">Subscribe</button>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div> -->

	<footer id="fh5co-footer" role="contentinfo">
		<div class="container">
			<div class="row row-pb-md">
				<div class="col-md-4 fh5co-widget">
					<h3>Beckieddia.</h3>
					<p>Facilis ipsum reprehenderit nemo molestias. Aut cum mollitia reprehenderit. Eos cumque dicta adipisci architecto culpa amet.</p>
				</div>
				<div class="col-md-2 col-sm-4 col-xs-6 col-md-push-1">
					<ul class="fh5co-footer-links">
						<li><a href="#">Cameron</a></li>
						<li><a href="#">Shop on Demand</a></li>
						<li><a href="#">Contact</a></li>
					</ul>
				</div>

				<div class="col-md-2 col-sm-4 col-xs-6 col-md-push-1">
					<ul class="fh5co-footer-links">
						<li><a href="#">Shop</a></li>
						<li><a href="#">Privacy</a></li>
						<li><a href="#">Testimonials</a></li>
						<li><a href="#">Handbook</a></li>
						<li><a href="#">Held Desk</a></li>
					</ul>
				</div>

				<div class="col-md-2 col-sm-4 col-xs-6 col-md-push-1">
					<ul class="fh5co-footer-links">
						<li><a href="#">Find Designers</a></li>
						<li><a href="#">Find Developers</a></li>
						<li><a href="#">Teams</a></li>
						<li><a href="#">Advertise</a></li>
						<li><a href="#">API</a></li>
					</ul>
				</div>
			</div>

			<div class="row copyright">
				<div class="col-md-12 text-center">
					<p>
						<small class="block">&copy; Beckieddia. All Rights Reserved.</small> 
					</p>
					<p>
						<ul class="fh5co-social-icons">
							<li><a href="#"><i class="icon-twitter"></i></a></li>
							<li><a href="#"><i class="icon-facebook"></i></a></li>
							<li><a href="#"><i class="icon-linkedin"></i></a></li>
							<li><a href="#"><i class="icon-dribbble"></i></a></li>
						</ul>
					</p>
				</div>
			</div>

		</div>
	</footer>
	</div>

	<div class="gototop js-top">
		<a href="#" class="js-gotop"><i class="icon-arrow-up"></i></a>
	</div>
	
	<!-- jQuery -->
	<script src="js/jquery.min.js"></script>
	<!-- jQuery Easing -->
	<script src="js/jquery.easing.1.3.js"></script>
	<!-- Bootstrap -->
	<script src="js/bootstrap.min.js"></script>
	<!-- Waypoints -->
	<script src="js/jquery.waypoints.min.js"></script>
	<!-- Carousel -->
	<script src="js/owl.carousel.min.js"></script>
	<!-- countTo -->
	<script src="js/jquery.countTo.js"></script>
	<!-- Flexslider -->
	<script src="js/jquery.flexslider-min.js"></script>
	<!-- Main -->
	<script src="js/main.js"></script>

	</body>
</html>

