<html>
<head>
    <meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Cameron &mdash; For your dreams</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">

  	<!-- Facebook and Twitter integration -->
	<meta property="og:title" content=""/>
	<meta property="og:image" content=""/>
	<meta property="og:url" content=""/>
	<meta property="og:site_name" content=""/>
	<meta property="og:description" content=""/>
	<meta name="twitter:title" content="" />
	<meta name="twitter:image" content="" />
	<meta name="twitter:url" content="" />
	<meta name="twitter:card" content="" />

	<link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Playfair+Display:400,400i" rel="stylesheet">
	
	<!-- Animate.css -->
	<link rel="stylesheet" href="css/animate.css">
	<!-- Icomoon Icon Fonts-->
	<link rel="stylesheet" href="css/icomoon.css">
	<!-- Bootstrap  -->
	<link rel="stylesheet" href="css/bootstrap.css">

	<!-- Flexslider  -->
	<link rel="stylesheet" href="css/flexslider.css">

	<!-- Owl Carousel  -->
	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<link rel="stylesheet" href="css/owl.theme.default.min.css">

	<!-- Theme style  -->
	<link rel="stylesheet" href="css/style.css">

	<!-- Font Awesome -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">

	<!-- Modernizr JS -->
	<script src="js/modernizr-2.6.2.min.js"></script>
	<!-- FOR IE9 below -->
	<!--[if lt IE 9]>
	<script src="js/respond.min.js"></script>
	<![endif]-->
	<style>
		body {
    background: #f5f5f5
}

.rounded {
    border-radius: 1rem
}

.nav-pills .nav-link {
    color: #555
}

.nav-pills .nav-link.active {
    color: white
}

input[type="radio"] {
    margin-right: 5px
}

.bold {
    font-weight: bold
}
/* payment form css */
 .wrapper{
	 background-color:rgb(255, 253, 253);
	 width: 500px;
	 padding:25px;
	 margin:25px auto 0;
	 box-shadow: 0px 0px 20px;
 }
.wrapper h2{
	background-color:#6b6666;
	color:white;
	font-size:24px;
	padding:10px;
	margin-bottom: 20px;
	text-align:center;
	border:1px dotted #333;

}
h4{
	padding-bottom:5px;
	color:#6b6666;
	font-size:20px;
	font-weight:bold;
}
.input-group{
padding-bottom: 8px;
width:100%;
position:relative;
display:flex;
flex-direction:row;
padding:5px 0;
}

.input-box{
	width:100%;
	margin-right:12px;
	position:relative;
}
.name{
	padding:14px 10px 14px 50px;
	width:100%;
	background-color:#fcfcfc;
	border:	1px solid #4b4a4a33;
	outline:none;
	letter-spacing:1px;
	transition:0.3s;
	border-radius:3px;
	color:#333;
}
.name:focus, .dob:focus{
	-webkit-box-shadow:0 0 2px 1px rgb(76, 71, 71);
	-moz-box-shadow:0 0 2px 1px rgb(76, 71, 71);
	box-shadow:0 0 2px 1px rgb(76, 71, 71);
	border:1px solid rgb(76, 71, 71);
}
.input-box.icon{
	width: 48px;
	display:flex;
	justify-content:centred;
	align-items:center;
	position:absolute;
	top:0px;
	left:0px;
	bottom:0px;
	color:#333;
	background-color:#f5f5f5;
	border-radius:2px 0 0 2px;
	transition:0.3s;
	font-size: 20px;
	pointer-events:none;
	border:1px solid  rgb(71, 70, 70);
	border-right: none;

}
.name:focus + .icon{
	background-color:#6b6868;
	color:#fff;
	border-right:1px solid grey;
	border:none;
	transition:1s;
}
.dob{
	width:30%;
	padding:14px;
	text-align:center;
	background-color:#fcfcfc;
	transition:0.3s;
	outline:none;
	border:1px solid rgb(224, 217, 217)
}
.radio{
	display:none;
}
.input-box label{
	width:50%;
	padding:13px;
	background-color:#fcfcfc;
	display:inline-block;
	float:left;
	text-align: center;
	border:1px solid #c0c0c0;
}
.input-box label:first-of-type{
	border-bottom-left-radius:3px;
	border-bottom-left-radius:3px;
	border-right:none
}
.input-box label:last-of-type{
	border-top-right-radius:3px;
	border-bottom-right-radius: 3px;
}
.radio:checked +label{
background-color:#6b6666;
color:#f5f5f5;
transition:0.5s
} 
.radio lable{
	width:100%;
	margin-right:12px;
	position:relative;
}
.input-box select{
	display:inline-block;
	width:50%;
	padding:12px;
	background-color: #fcfcfc;
	float:left;
	text-align: center;
	font-size: 16px;
	outline:none;
	border:1px solid #c0c0c0;
	cursor:pointer;
	transition:all 0.2s ease;
}
.input-box select:focus{
	background-color:#6b6666;
	color:#fff;
	text-align:center;

}
button{
	width:100%;
	background: transparent;
	border:none;
	color:#fff;
	background:#6b6666;
	padding:15px;
	border-radius:4px;
	font-size:16px;
	transiton:all 0.35s ease;

}
button:hover{
	cursor:pointer;
	background:#2b2a2a;

}
@media only screen and (max-width: 475px) {
	.wrapper{
		width:400px;
		
	}
	.name{
		padding: 5px 10px;
	}
}
	</style>

</head>
<body>
		
	<div class="fh5co-loader"></div>
	
	<div id="page">
	<nav class="fh5co-nav" role="navigation">
		<div class="container">
			<div class="row">
				<div class="col-md-3 col-xs-2">
					<div id="fh5co-logo"><a href="{{ url('/') }}">Beckieddia</a></div>
				</div>
				<div class="col-md-6 col-xs-6 text-center menu-1">
					<ul>
						<li><a href="{{ url('/') }}">Cameron</a></li>
						<li><a href="{{ url('/amazon') }}">Shop on demand</a></li>
						<li><a href="{{ url('/contact') }}">Contact</a></li>
					</ul>
				</div>
				<div class="col-md-3 col-xs-4 text-right hidden-xs menu-2">
					<ul>
						<!-- <li class="search">
							<div class="input-group">
						      <input type="text" placeholder="Search..">
						      <span class="input-group-btn">
						        <button class="btn btn-primary" type="button"><i class="icon-search"></i></button>
						      </span>
						    </div>
						</li> -->
						<li class="user-account has-dropdown">
							<a href="#" class="account hide"><i class="fas fa-user"></i></a>
							<a class="account" href="{{ url('/login') }}">Login</a>
							<span class="dropdown hide" id="user-name">Hamid</span>
						</li>
						<li class="shopping-cart"><a href="{{ url('/cart') }}" class="cart"><span><small>0</small><i class="icon-shopping-cart"></i></span></a></li>
					</ul>
				</div>
			</div>
		</div>
	</nav>
    
	<!-- -----------Payment Form-------------- -->
	<div class="wrapper">
		<h2>Payment Form</h2>
		<form method="post" >
		    <h4>Account</h4>
		    <div class="input-group">
			    <div class="input-box">
				    <input type="text" placeholder="Full Name" required class="form-group name">
				    <!-- <i class="fa fa-user icon"></i> -->
			    </div>
			    <div class="input-box">
				    <input type="text" placeholder="Nick Name" required class="name">
				    <!-- <i class="fa fa-user icon"></i> -->
			    </div>
		    </div>
		    <div class="input-group">
			    <div class="input-box">
				    <input type="email" placeholder="Email Address" required class="name" >
				    <!-- <i class="fa fa-envelope"></i> -->
			    </div>
		    </div>
		    <div class="input-group"> 
			    <div class="input-box">
					<h4>Date of Birth</h4>
					<input type="text" placeholder="DD" required class="dob" >
					<input type="text" placeholder="MM" required class="dob" >
					<input type="text" placeholder="YYYY" required class="dob" >   
				</div>
				<div class="input-box">
				    <h4>Gender</h4>
				    <input type="radio" id="b1" name="gender" checked class="radio">
				    <label for="b1">Male</label>
				    <input type="radio" id="b2" name="gender"  class="radio">
				    <label for="b2">Female</label>
			    </div>
		    </div>
		    <div class="input-group">
  			    <div class="input-box">
				    <h4>Payment Details</h4>
				    <input type="radio" name="pay" id="bc1" checked class="radio" >
				    <label  for="bc1" >Credit Card</label>
				    <input type="radio" name="pay" id="bc2" checked class="radio" >
				    <label  for="bc2" >Paypal</label>
			 	</div>
			</div> 
			<div class="input-group">
				<div class="input-box">
					<input type="tel" placeholder="Card Number" required class="name">
					<!-- <i class="fa fa-credit-card icon"></i> -->
			 	</div>
			</div> 
			<div class="input-group">
			 	<div class="input-box">
					<input type="tel" placeholder="Card CVC" required class="name">
				 	<!-- <i class="fa fa-user icon"></i> -->
				</div>
				<div class="input-box">
					<select>
						<option value="">04 April</option>
						<option value="">05 April</option>
						<option value="">06 April</option>
				 	</select>
				 	<select>
						<option value="">2021</option>
						<option value="">2022</option>
						<option value="">2023</option>
					</select>
			 	</div>
			</div>  
		 	<div class="input-group">
			 	<div class="input-box">
				 	<button  type="submit">PAY NOW</button>
			 	</div>
		 	</div>
		</form>
	</div> 

	

	

	<!-- ----------------------footer--------------- -->
    <footer id="fh5co-footer" role="contentinfo">
		<div class="container">
			<div class="row row-pb-md">
				<div class="col-md-4 fh5co-widget">
					<h3>Beckieddia.</h3>
					<p>Facilis ipsum reprehenderit nemo molestias. Aut cum mollitia reprehenderit. Eos cumque dicta adipisci architecto culpa amet.</p>
				</div>
				<div class="col-md-2 col-sm-4 col-xs-6 col-md-push-1">
					<ul class="fh5co-footer-links">
						<li><a href="#">Cameron</a></li>
						<li><a href="#">Shop on Demand</a></li>
						<li><a href="#">Contact</a></li>
					</ul>
				</div>

				<div class="col-md-2 col-sm-4 col-xs-6 col-md-push-1">
					<ul class="fh5co-footer-links">
						<li><a href="#">Shop</a></li>
						<li><a href="#">Privacy</a></li>
						<li><a href="#">Testimonials</a></li>
						<li><a href="#">Handbook</a></li>
						<li><a href="#">Held Desk</a></li>
					</ul>
				</div>

				<div class="col-md-2 col-sm-4 col-xs-6 col-md-push-1">
					<ul class="fh5co-footer-links">
						<li><a href="#">Find Designers</a></li>
						<li><a href="#">Find Developers</a></li>
						<li><a href="#">Teams</a></li>
						<li><a href="#">Advertise</a></li>
						<li><a href="#">API</a></li>
					</ul>
				</div>
			</div>

			<div class="row copyright">
				<div class="col-md-12 text-center">
					<p>
						<small class="block">&copy; Beckieddia. All Rights Reserved.</small> 
					</p>
					<p>
						<ul class="fh5co-social-icons">
							<li><a href="#"><i class="icon-twitter"></i></a></li>
							<li><a href="#"><i class="icon-facebook"></i></a></li>
							<li><a href="#"><i class="icon-linkedin"></i></a></li>
							<li><a href="#"><i class="icon-dribbble"></i></a></li>
						</ul>
					</p>
				</div>
			</div>

		</div>
	</footer>
	</div>
    <script> $(function() {
		$('[data-toggle="tooltip"]').tooltip()
		})</script>
	<div class="gototop js-top">
		<a href="#" class="js-gotop"><i class="icon-arrow-up"></i></a>
	</div>
	
	<!-- jQuery -->
	<script src="js/jquery.min.js"></script>
	<!-- jQuery Easing -->
	<script src="js/jquery.easing.1.3.js"></script>
	<!-- Bootstrap -->
	<script src="js/bootstrap.min.js"></script>
	<!-- Waypoints -->
	<script src="js/jquery.waypoints.min.js"></script>
	<!-- Carousel -->
	<script src="js/owl.carousel.min.js"></script>
	<!-- countTo -->
	<script src="js/jquery.countTo.js"></script>
	<!-- Flexslider -->
	<script src="js/jquery.flexslider-min.js"></script>
	<!-- Main -->
	<script src="js/main.js">
	</script>
<body>
    
</body>
</html>


