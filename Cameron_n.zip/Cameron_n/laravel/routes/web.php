<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('index');
});

Route::get('/login', function () {
    return view('login');
});

Route::get('/brands', function () {
    return view('brands');
});

Route::get('/amazon', function () {
    return view('amazon');
});

Route::get('/contact', function () {
    return view('contact');
});

Route::get('/cart', function () {
    return view('cart');
});

Route::get('/single', function () {
    return view('single');
});

Route::get('/payment', function () {
    return view('payment');
});

Route::get('/signup', function () {
    return view('signup');
});

Route::get('/services', function () {
    return view('services');
});

Route::get('/dashboard', function () {
    return view('dashboard');
});

Route::get('/home', function () {
    return view('home');
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

Route::resource('admin', 'ProductController');
Route::get('admin/{id}/editOrder', 'ProductController@editOrder');
Route::patch('admin/{id}/updateOrder', 'ProductController@updateOrder');
Route::get('product/delete/{id}', ['as' => 'product.delete', 'uses' => 'ProductController@destroy']);
Route::get('order/delete/{id}', ['as' => 'order.delete', 'uses' => 'ProductController@destroyOrder']);
Route::patch('product/add', ['as' => 'product.add', 'uses' => 'ProductController@store']);